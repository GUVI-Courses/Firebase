import React from "react";
import { BrowserRouter, Routes ,Route } from "react-router-dom";
import Login from "./pages/login";
import Signup from "./pages/signup";
import Home from "./pages/home";
import Drawer from "./components/drawer";
import { auth } from "./config/firebase";
import ForgotPassword from "./pages/forgot-password";
import AllPosts from "./pages/all-posts.jsx";
import AddPost from "./pages/add-post";
import UserProfile from "./pages/profile/index.jsx";
import Comments from "./pages/comments/index.jsx";
const App = () => {

  console.log(auth?.currentUser?.email)
  return (
    <div>
      <BrowserRouter basename="/">
      <Drawer/>
        <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/all-posts" element={<AllPosts />} />
        <Route path="/add-post" element={<AddPost />} />
        <Route path="/user-profile" element={<UserProfile />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/comments" element={<Comments />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
};

export default App;
