import React, { useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { auth } from '../../config/firebase'
import { ExitToApp } from '@mui/icons-material'
import { useAuth } from '../../store/AuthContext'

const Drawer = () => {
  // const [user, setuser] = React.useState(null)

  // useEffect(()=>{
  //   const unsubscribe=auth.onAuthStateChanged((user)=>{
  //     setuser(user);
  //   })
  //   return ()=>{
  //     unsubscribe();
  //   }
  // }
  // ,[])

  // console.log(user)

  const navigate=useNavigate();



  const {currentUser}=useAuth();
  const onHandleSignOut=()=>{
    auth.signOut();
  }

  console.log(currentUser)


  return (
    <div className='bg-blue-500 p-4 flex justify-between'>
        <h3 className='text-xl font-bold text-white'>SOCIAL</h3>
        <div className='flex gap-2'>
            <Link to={'/'} className='bg-black p-2 text-white'>HOME</Link>
            {!currentUser && <Link to={'/signup'} className='bg-black p-2 text-white'>SIGNUP</Link>}
            {!currentUser && <Link to={'/login'} className='bg-black p-2 text-white'>LOGIN</Link>}
            {currentUser && <button onClick={()=>onHandleSignOut()} className='bg-black p-2 text-white'><ExitToApp/>LOGOUT</button>}
        </div>
    </div>
  )
}

export default Drawer