import React, { useEffect } from 'react'
import { useAuth } from '../../store/AuthContext'
import { useNavigate } from 'react-router-dom';

const ProtectRoutes = ({children}) => {
    const {currentUser}=useAuth();

    const navigate=useNavigate();

    useEffect(()=>{
        if(!currentUser){
            navigate('/login')
        }
    },[currentUser])
  return (
    <div>{children}</div>
  )
}

export default ProtectRoutes