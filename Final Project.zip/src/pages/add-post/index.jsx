import React, { useEffect, useState } from "react";
import { db, storage } from "../../config/firebase";
import { deleteObject, getDownloadURL, ref, uploadBytes } from "firebase/storage";
import { addDoc, collection, doc, getDoc, updateDoc } from "firebase/firestore";
import { useAuth } from "../../store/AuthContext";
import { useLocation } from "react-router-dom";
import ProtectRoutes from "../../components/protect-routes/ProtectRoutes";
const AddPost = () => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [image, setImage] = useState(null);
  const [preview, setPreview] = useState(null);
  const [oldData, setOldData] = useState(null);

  const location = useLocation();

  const queryParams = new URLSearchParams(location.search);
  const edit = queryParams.get("edit");
  const id = queryParams.get("id");

  console.log(id);
  useEffect(() => {
    if (edit) {
      // const postsRef=collection(db,'posts');
      const fetchData = async () => {
        const docRef = doc(db, "posts", id);
        try {
          const doc = await getDoc(docRef);
          console.log(doc.data());
          setTitle(doc.data().title);
          setDescription(doc.data().description);
          setPreview(doc.data().image);
          setOldData(doc.data());
        } catch (err) {
          console.log(err);
        }
      };

      fetchData();
    }
  }, [edit, id]);

  useEffect(() => {
    if (!image) {
      setPreview(null);
      return;
    }
    const objectUrl = URL.createObjectURL(image);
    setPreview(objectUrl);
  }, [image]);

  const imageRef = ref(storage, "images/" + Math.random().toString());
  const postsRef = collection(db, "posts");

  const { currentUser } = useAuth();

  console.log(currentUser?.uid);

  const onAddPost = async (url) => {
    try {
      await addDoc(postsRef, {
        title: title,
        description: description,
        image: url,
        createdBy: {
          uid: currentUser?.uid,
          displayName: currentUser?.displayName
            ? currentUser?.displayName
            : currentUser?.email,
        },
        likeCount: 0,
        likedBy:[],
        comments:[],
      });

      setImage(null);
      setTitle("");
      setDescription("");
    } catch (err) {
      console.log(err);
    }
  };

  const onHandleSubmit = () => {
    if (!title || !description || !preview) {
      return alert("Please fill all the fields");
    }

    uploadBytes(imageRef, image)
      .then((snapshot) => {
        getDownloadURL(snapshot.ref).then((url) => {
          onAddPost(url);
        });
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const onUpdateHandler = async () => {
    if (!title || !description || !preview) {
      return alert("Please fill all the fields");
    }

    const updatingPost = async (url) => {
      try {
        const postDoc = doc(db, "posts", id);
        await updateDoc(postDoc, {
          title: title,
          description: description,
          image: url,
          createdBy: {
            uid: currentUser?.uid,
            displayName: currentUser?.displayName
              ? currentUser?.displayName
              : currentUser?.email,
          },
          likeCount: oldData.likeCount,
          likedBy:oldData.likedBy,
          comments:oldData.comments,
          
        });
        alert("Post updated successfully");
      } catch(err) {
        console.log(err)
      }
    };

    if (image) {
      uploadBytes(imageRef, image)
        .then((snapshot) => {
          getDownloadURL(snapshot.ref).then((url) => {
            updatingPost(url);
          });
          const imageRef=ref(storage,oldData.image);
           deleteObject(imageRef);
        })
        .catch((err) => {
          console.log(err);
        });
    } else {
      updatingPost(oldData.image);
    }
  };

  return (
    <ProtectRoutes>
    <div className="p-4 flex flex-col gap-4">
      <h2 className="text-2xl">{edit ? "EDIT POST" : "ADD POST"}</h2>
      <div className="w-[480px] flex flex-col gap-4">
        <div className="flex flex-col gap-2">
          <label>POST TITLE</label>
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            type="tsext"
            placeholder="Post Title"
            className="p-2 bg-blue-200 rounded-sm"
          />
        </div>

        <div className="flex flex-col gap-2">
          <label>POST DESCRIPTION</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Post Description"
            className="p-2 bg-blue-200 rounded-sm"
          />
        </div>

        <div className="flex flex-col gap-2">
          <label>IMAGE</label>
          <input onChange={(e) => setImage(e.target.files[0])} type="file" />
        </div>
        {preview && (
          <div>
            <img
              src={preview}
              alt="Preivew"
              className="w-full h-[320px] object-contain"
            />
          </div>
        )}
        {edit ? (
          <button onClick={onUpdateHandler} className="bg-black text-white p-2">
            UPDATE
          </button>
        ) : (
          <button onClick={onHandleSubmit} className="bg-black text-white p-2">
            POST
          </button>
        )}
      </div>
    </div>
    </ProtectRoutes>
  );
};

export default AddPost;
