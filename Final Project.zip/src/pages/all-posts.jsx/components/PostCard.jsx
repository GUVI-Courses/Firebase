import { Comment, Delete, Edit, Favorite, Person } from "@mui/icons-material";
import { Icon, IconButton } from "@mui/material";
import React, { useState } from "react";
import { useAuth } from "../../../store/AuthContext";
import { db, storage } from "../../../config/firebase";
import { doc, deleteDoc, updateDoc } from "firebase/firestore";
import { deleteObject, ref } from "firebase/storage";
import { useNavigate } from "react-router-dom";
const PostCard = ({ item, fetchData, posts, setPosts }) => {
  const { currentUser } = useAuth();
  const [liked, setLiked] = useState(item?.likedBy?.includes(currentUser?.uid));

  const onDeleteHandler = async (id) => {
    try {
      const postDoc = doc(db, "posts", id);
      const imageRef = ref(storage, item?.image);
      await deleteObject(imageRef);
      await deleteDoc(postDoc);
      fetchData();
    } catch (err) {
      console.log(err);
    }
  };

  const navigate = useNavigate();

  const onHandleLike = () => {
    const updatingPost = async (url) => {
      try {
        const postDoc = doc(db, "posts", item?.id);
        await updateDoc(postDoc, {
          ...item,
          likeCount: liked ? item?.likeCount - 1 : item?.likeCount + 1,
          likedBy: liked
            ? item?.likedBy.filter((id) => id !== currentUser?.uid)
            : [...item?.likedBy, currentUser?.uid],
        });
        setLiked(!liked);
        console.log("updated");
        const temp = item;

        temp.likeCount = liked ? item?.likeCount - 1 : item?.likeCount + 1;
        temp.likedBy = liked
          ? item?.likedBy.filter((id) => id !== currentUser?.uid)
          : [...item?.likedBy, currentUser?.uid];
        let tempPosts = posts.map((post) =>
          post.id === item.id ? temp : post
        );
        setPosts(tempPosts);
      } catch (err) {
        console.log(err);
      }
    };

    updatingPost();
  };

  return (
    <div className="w-[320px] bg-pink-100 p-4 rounded-lg flex flex-col gap-2">
      <div className="flex gap-2 items-center justify-between">
        <div className="flex gap-2 items-center">
          <Person />
          <h4 className="text-xl">{item?.createdBy?.displayName}</h4>
        </div>
        <div>
          {item?.createdBy?.uid === currentUser?.uid && (
            <IconButton
              onClick={() => navigate(`/add-post?id=${item.id}&edit=true`)}
            >
              <Edit />
            </IconButton>
          )}
          {item?.createdBy?.uid === currentUser?.uid && (
            <IconButton onClick={() => onDeleteHandler(item?.id)}>
              <Delete />
            </IconButton>
          )}
        </div>
      </div>
      <div>
        <h4 className="text-xl">{item?.title}</h4>
        <p>{item.description}</p>
      </div>
      <div className="h-[320x] p-2 bg-white">
        <img
          src={item?.image}
          alt="post"
          className="w-full h-full object-cover"
        />
      </div>

      <div className="flex">
        <IconButton onClick={() => onHandleLike()}>
          {liked ? <Favorite sx={{ color: "red" }} /> : <Favorite />}
          <p className="text-sm">{item?.likeCount}</p>
        </IconButton>

        <IconButton onClick={()=>navigate('/comments?postId='+item?.id)} >
          <Comment />
          <p className="text-sm">{item?.comments.length}</p>
        </IconButton>
      </div>
    </div>
  );
};

export default PostCard;
