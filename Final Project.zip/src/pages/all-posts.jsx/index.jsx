import React, { useEffect, useState } from 'react'
import { db } from '../../config/firebase'
import { collection, getDocs } from 'firebase/firestore'
import PostCard from './components/PostCard'
import { Switch } from '@mui/material'
import { useAuth } from '../../store/AuthContext'
import ProtectRoutes from '../../components/protect-routes/ProtectRoutes'
const AllPosts = () => {
    const [posts,setPosts]=useState([]);
    const [AllPosts,setAllPosts]=useState(true);
    const postsRef=collection(db,'posts');
    const [loading,setLoading]=useState(true);

    const {currentUser}=useAuth();

    const fetchData=async()=>{
        try{
            const data=await getDocs(postsRef);
            const temp=data.docs.map((doc)=>({...doc.data(),id:doc.id}))

            setPosts(temp)
            setLoading(false)
        }
        catch(err){
            console.log(err)
        }
    }

    useEffect(()=>{
      
        if(posts.length===0 || AllPosts){
        fetchData();
        }
        else if(!AllPosts){
            let temp=posts.filter((post)=>post.createdBy.uid===currentUser?.uid);
            setPosts(temp)
        }
    },[AllPosts])

    console.log(AllPosts)
  return (
    <ProtectRoutes>
    <div className='p-4 flex flex-col gap-2'>
        <h1 className='text-2xl'>{AllPosts ? 'All Posts' : 'My Posts'}</h1>
        <Switch checked={AllPosts} onChange={(e)=>setAllPosts(e.target.checked)}/>

        <div className='flex flex-col gap-4'>
            {posts.map((post,i)=>(
                <PostCard posts={posts} setPosts={setPosts} fetchData={fetchData} key={i} item={post}/>
            ))}
        </div>

        {posts.length===0  &&!loading && <h1 className='text-2xl'>No Posts</h1>}
        {loading && <h1 className='text-2xl'>Loading...</h1>}
    </div>
    </ProtectRoutes>
  )
}

export default AllPosts