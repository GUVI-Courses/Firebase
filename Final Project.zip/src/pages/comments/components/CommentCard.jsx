import { Delete, Person } from "@mui/icons-material";
import { IconButton } from "@mui/material";
import React from "react";
import { useAuth } from "../../../store/AuthContext";

const CommentCard = ({ comment,onDeleteHandler }) => {
  const {currentUser}=useAuth();
  return (
    <div className="bg-blue-200 p-2 rounded-lg">
      <div className="flex gap-2">
        <div className="w-8 h-8 bg-white flex items-center justify-center rounded-full">
          <Person />
        </div>
        <p className="font-bold flex-1">{comment?.userName}</p>
        {currentUser?.uid === comment?.uid && 
        <IconButton onClick={()=>onDeleteHandler(comment?.commentId)}>
          <Delete />
        </IconButton>
}
      </div>
      <p>{comment?.comment}</p>
      <p className="text-xs font-light">Commented on {new Date(comment?.createdAt).toDateString()}
      at {new Date(comment?.createdAt).toLocaleTimeString()}
      </p>
    </div>
  );
};

export default CommentCard;
