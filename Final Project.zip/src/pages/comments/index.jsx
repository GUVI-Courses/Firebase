import React, { useEffect, useState } from "react";
import CommentCard from "./components/CommentCard";
import { IconButton } from "@mui/material";
import { Send } from "@mui/icons-material";
import { doc, getDoc, updateDoc } from "firebase/firestore";
import { db } from "../../config/firebase";
import { useLocation } from "react-router-dom";
import { useAuth } from "../../store/AuthContext";

const Comments = () => {
  const location = useLocation();
  const [post, setPost] = useState(null);
  const [comments, setComments] = useState([]);
  const [comment, setComment] = useState("");
  const [loading, setLoading] = useState(true);

  const queryParams = new URLSearchParams(location.search);
  const postId = queryParams.get("postId");
  const { currentUser } = useAuth();

  const fetchData = async () => {
    setLoading(true);
    const docRef = doc(db, "posts", postId);
    try {
      const doc = await getDoc(docRef);
      console.log(doc.data());
      setPost(doc.data());
      setComments(doc.data().comments);
    } catch (err) {
      console.log(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (postId) {
      fetchData();
    }
  }, [postId]);

  const onSubmitHandler = async () => {
    if (!comment) {
      return alert("Please enter a comment");
    }
    const body = {
      ...post,
      comments: [
        ...post.comments,
        {
          comment,
          commentId: Math.random().toString(36).substr(2, 9),
          uid: currentUser?.uid,
          createdAt: new Date().toISOString(),
          userName: currentUser?.displayName
            ? currentUser?.displayName
            : currentUser?.email.split("@")[0],
        },
      ],
    };

    const updatingPost = async () => {
        try {
          const postDoc = doc(db, "posts", postId);
          await updateDoc(postDoc, {
            ...body
          });
          setComment("");
          fetchData();
        } catch(err) {
          console.log(err)
        }
      };

      updatingPost();
  };

  const onDeleteHandler = async (commentId) => {
    const body = {
      ...post,
      comments: post.comments.filter((comment) => comment.commentId !== commentId),
    };

    const updatingPost = async () => {
        try {
          const postDoc = doc(db, "posts", postId);
          await updateDoc(postDoc, {
            ...body
          });
          setComment("");
          fetchData();
        } catch(err) {
          console.log(err)
        }
      };

      updatingPost();
  }

  return (
    <div className="p-4 w-[320px] flex flex-col gap-4">
      <div className="h-[75vh] flex flex-col gap-2 overflow-y-auto pr-4">
        {!loading &&
          comments.map((comment,i) => <CommentCard onDeleteHandler={onDeleteHandler} key={i} comment={comment} />)}
        {loading && <p>Loading...</p>}
        {!loading && comments.length === 0 && <p>No comments yet</p>}
      </div>

      <div className="flex gap-2">
        <textarea
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder="Add a comment"
          className="w-full mt-auto bg-blue-200 p-2 rounded-lg outline-none resize-none"
        />
        <IconButton onClick={onSubmitHandler}>
          <Send />
        </IconButton>
      </div>
    </div>
  );
};

export default Comments;
