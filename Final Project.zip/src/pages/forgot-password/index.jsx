import React, { useEffect } from "react";
import {  useNavigate } from "react-router-dom";
import { auth } from "../../config/firebase";
import { sendPasswordResetEmail } from "firebase/auth";
import { useAuth } from "../../store/AuthContext";
const ForgotPassword = () => {
  const [email, setEmail] = React.useState("");

  const onSubmitHandler = async () => {
    if (!email ) {
      return;
    }

    try {
      await sendPasswordResetEmail(auth, email);
      alert('Email sent successfully')

    } catch (err) {
      console.log(err);
    }
  };

  const {currentUser}=useAuth();
  const navigate=useNavigate();



  useEffect(()=>{
    if(currentUser){
      navigate('/');
    }
  },[currentUser])

  return (
    <div className="h-[90vh] flex justify-center items-center">
      <div className="w-[100%] m-4 md:w-[600px] bg-purple-300 px-4 py-8 rounded-xl">
        <h2 className="text-2xl font-bold">FORGOT PASSWORD</h2>
        <div className="flex flex-col gap-4">
          <div className="flex flex-col gap-2">
            <label htmlFor="email">Email</label>
            <input
              onChange={(e) => setEmail(e.target.value)}
              value={email}
              type="text"
              placeholder="alex@gmail.com"
              className="p-2"
            />
          </div>
          <button
            onClick={onSubmitHandler}
            className="w-full p-2 bg-black text-white"
          >
            SEND EMAIL
          </button>

        </div>
      </div>
    </div>
  );
};

export default ForgotPassword;
