import React from "react";
import { useAuth } from "../../store/AuthContext";
import { Link } from "react-router-dom";
import { Add, DynamicFeed, Person } from "@mui/icons-material";

const Home = () => {
  const { currentUser } = useAuth();
  console.log(currentUser);
  return (
    <div className="p-4 flex flex-col gap-4">
      {currentUser && (
        <h1 className="text-2xl font-bold">
          Hey ,{" "}
          {currentUser?.displayName
            ? currentUser?.displayName
            : currentUser?.email}{" "}
          !
        </h1>
      )}
      {currentUser && (
        <div className="flex flex-col gap-4 text-white">
          <Link
            className="bg-black p-2 w-80 flex justify-center gap-2"
            to={"/all-posts"}
          >
            <DynamicFeed /> All Posts
          </Link>
          <Link
            className="bg-black p-2 w-80 flex justify-center gap-2"
            to={"/add-post"}
          >
            <Add /> Add Post
          </Link>
          <Link
            className="bg-black p-2 w-80 flex justify-center gap-2"
            to={"/user-profile"}
          >
            <Person />
            User Profile
          </Link>
        </div>
      )}

      {!currentUser && 
      <div>
        <h3 className="text-xl">USER IS NOT LOGGED IN , PLEASE LOGIN TO SEE CONTENT</h3>
        </div>}
    </div>
  );
};

export default Home;
