import React, { useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import GoogleIcon from '@mui/icons-material/Google';
import { auth } from '../../config/firebase';
import { signInWithEmailAndPassword,GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import { useAuth } from '../../store/AuthContext';
const Login = () => {

    const [email, setEmail] = React.useState('');
    const [password, setPassword] = React.useState('');

    const onSubmitHandler=async()=>{
        if(!email || !password){
            return
        }

        try{
            await signInWithEmailAndPassword(auth,email,password);
            console.log('user login successfully');
        }
        catch(err){
            console.log(err);
            alert(err.message);
        }

    }

    const {currentUser}=useAuth();
    const navigate=useNavigate();

  
    console.log(currentUser)
  
    useEffect(()=>{
      if(currentUser){
        navigate('/');
      }
    },[currentUser])

    const onHandleGoogleLogin=async()=>{
        const provider=new GoogleAuthProvider();
        try{
            const result=await signInWithPopup(auth,provider);

        }
        catch(err){
            console.log(err);
        }

    }
  return (
    <div className='h-[90vh] flex justify-center items-center'>
        <div className='w-[100%] m-4 md:w-[600px] bg-purple-500 px-4 py-8 rounded-xl'>
           <h2 className='text-2xl font-bold'>LOGIN</h2>
           <div className='flex flex-col gap-4'>
            <div className='flex flex-col gap-2'>
                <label htmlFor='email'>Email</label>
                <input onChange={(e)=>setEmail(e.target.value)} value={email} type='text' placeholder='alex@gmail.com' className='p-2'/>
            </div>

            <div className='flex flex-col gap-2'>
                <label htmlFor='password'>Password</label>
                <input onChange={(e)=>setPassword(e.target.value)} value={password} type='password' placeholder='*********' className='p-2'/>
            </div>

            <button onClick={onSubmitHandler} className='w-full p-2 bg-black text-white'>LOGIN</button>
            <button onClick={onHandleGoogleLogin} className='w-full p-2 bg-orange-500 text-white flex g justify-center gap-2'><GoogleIcon/>LOGIN WITH GOOGLE</button>
            <p>Does not have an account ? <Link to={'/signup'} className='text-blue-500'>SIGNUP</Link></p>
            <Link className='text-white' to={'/forgot-password'}>FORGOT PASSWORD</Link>
           </div>
        </div>
    </div>
  )
}

export default Login