import React from 'react'
import { useAuth } from '../../store/AuthContext'
import { lightGreen } from '@mui/material/colors';
import { Switch, TextField } from '@mui/material';
import ProtectRoutes from '../../components/protect-routes/ProtectRoutes';

const UserProfile = () => {
  const {currentUser}=useAuth();

  console.log(currentUser)
  return (
    <ProtectRoutes>
    <div className='p-4 flex flex-col gap-4 w-[320px]'>
      <img src={currentUser?.photoURL} width={100} height={100} className='rounded-full' alt='profile' />
      <TextField label='UID' value={currentUser?.uid} disabled={true} />
      <TextField label='Name' value={currentUser?.displayName} disabled={true} />
      <TextField label='Email' value={currentUser?.email} disabled={true} />
      <TextField label='Created At' value={currentUser?.metadata?.creationTime} disabled={true} />
      <TextField label='Last Login' value={currentUser?.metadata?.lastSignInTime} disabled={true} />

      <div className='flex items-center gap-2'>
        <p className='text-gray-500'>EMAIL VERIFIED</p>
        <Switch disabled={true} checked={currentUser?.emailVerified}  />
      </div>
    </div>
    </ProtectRoutes>
  )
}

export default UserProfile