import React, { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { auth } from "../../config/firebase";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { useAuth } from "../../store/AuthContext";
const Signup = () => {
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");

  const onSubmitHandler = async () => {
    if (!email || !password) {
      return;
    }

    try {
      await createUserWithEmailAndPassword(auth, email, password);
      console.log("user created successfully");
      setEmail("");
      setPassword("");
    } catch (err) {
      console.log(err);
    }
  };

  const {currentUser}=useAuth();
  const navigate=useNavigate();


  console.log(currentUser)

  useEffect(()=>{
    if(currentUser){
      navigate('/');
    }
  },[currentUser])
  return (
    <div className="h-[90vh] flex justify-center items-center">
      <div className="w-[100%] m-4 md:w-[600px] bg-purple-300 px-4 py-8 rounded-xl">
        <h2 className="text-2xl font-bold">SIGNUP</h2>
        <div className="flex flex-col gap-4">
          <div className="flex flex-col gap-2">
            <label htmlFor="email">Email</label>
            <input
              onChange={(e) => setEmail(e.target.value)}
              value={email}
              type="text"
              placeholder="alex@gmail.com"
              className="p-2"
            />
          </div>

          <div className="flex flex-col gap-2">
            <label htmlFor="password">Password</label>
            <input
              onChange={(e) => setPassword(e.target.value)}
              value={password}
              type="password"
              placeholder="*********"
              className="p-2"
            />
          </div>

          <button
            onClick={onSubmitHandler}
            className="w-full p-2 bg-black text-white"
          >
            SIGNUP
          </button>
          <p>
            Already have an account ?{" "}
            <Link to={"/login"} className="text-blue-500">
              LOGIN
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Signup;
